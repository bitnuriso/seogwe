#!/usr/bin/env python3

import argparse
import html
import json
import mimetypes
import os
import posixpath
import re
import threading
import time
from datetime import datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlsplit
import zipfile
import xml.etree.ElementTree as ET



METADATA_CACHE_DIR = Path.home() / ".bookserver"
METADATA_CACHE_FILE = METADATA_CACHE_DIR / "metadata.json"
METADATA_CACHE_LOCK = threading.RLock()


def load_metadata_cache():
    try:
        with METADATA_CACHE_FILE.open("r", encoding="utf-8") as file:
            data = json.load(file)

        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


METADATA_CACHE = load_metadata_cache()


DOWNLOAD_HISTORY_FILE = METADATA_CACHE_DIR / "download_history.json"
DOWNLOAD_HISTORY_LOCK = threading.RLock()
RECORDED_DOWNLOAD_TOKENS = set()


def load_download_history():
    try:
        with DOWNLOAD_HISTORY_FILE.open("r", encoding="utf-8") as file:
            data = json.load(file)

        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


DOWNLOAD_HISTORY = load_download_history()


def save_download_history():
    METADATA_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    temporary_file = DOWNLOAD_HISTORY_FILE.with_suffix(".json.tmp")

    with temporary_file.open("w", encoding="utf-8") as file:
        json.dump(
            DOWNLOAD_HISTORY,
            file,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )

    temporary_file.replace(DOWNLOAD_HISTORY_FILE)


def record_download(client_ip, file_path, token):
    file_path = os.path.realpath(os.path.abspath(file_path))

    with DOWNLOAD_HISTORY_LOCK:
        # 동일 다운로드 토큰의 중복 완료 기록 방지
        if token in RECORDED_DOWNLOAD_TOKENS:
            return

        RECORDED_DOWNLOAD_TOKENS.add(token)

        client_history = DOWNLOAD_HISTORY.setdefault(client_ip, {})
        entry = client_history.setdefault(
            file_path,
            {
                "count": 0,
                "last_downloaded": "",
            },
        )

        try:
            current_count = int(entry.get("count", 0))
        except (TypeError, ValueError):
            current_count = 0

        entry["count"] = current_count + 1
        entry["last_downloaded"] = datetime.now().isoformat(
            timespec="seconds"
        )

        try:
            save_download_history()
        except OSError as error:
            print(f"[WARN] 다운로드 기록 저장 실패: {error}")


def get_download_history(client_ip, file_path):
    absolute_path = os.path.abspath(file_path)
    real_path = os.path.realpath(absolute_path)
    wanted_name = os.path.basename(file_path).casefold()

    with DOWNLOAD_HISTORY_LOCK:
        client_history = DOWNLOAD_HISTORY.get(client_ip, {})

        print(
            "[HISTORY DEBUG]",
            "ip=", repr(client_ip),
            "wanted=", repr(file_path),
            "absolute=", repr(absolute_path),
            "real=", repr(real_path),
            "saved_keys=", list(client_history.keys()),
        )

        if not isinstance(client_history, dict):
            return None

        entry = client_history.get(real_path)

        if not isinstance(entry, dict):
            entry = client_history.get(absolute_path)

        # Termux 공유 저장소 경로 표현이 달라도
        # 마지막 파일명이 같으면 같은 책으로 본다.
        if not isinstance(entry, dict):
            for saved_path, saved_entry in client_history.items():
                if not isinstance(saved_entry, dict):
                    continue

                saved_name = os.path.basename(saved_path).casefold()

                if saved_name == wanted_name:
                    entry = saved_entry
                    break

        if not isinstance(entry, dict):
            return None

        try:
            count = int(entry.get("count", 0))
        except (TypeError, ValueError):
            count = 0

        return {
            "count": count,
            "last_downloaded": str(
                entry.get("last_downloaded", "")
            ),
        }




def build_download_history_modal(client_ip):
    with DOWNLOAD_HISTORY_LOCK:
        client_history = DOWNLOAD_HISTORY.get(client_ip, {})

        if not isinstance(client_history, dict):
            client_history = {}

        history_items = list(client_history.items())

    # 심볼릭 링크 경로와 실제 경로가 함께 저장된 경우 중복 제거
    merged = {}

    for saved_path, entry in history_items:
        if not isinstance(entry, dict):
            continue

        canonical_path = os.path.realpath(saved_path)
        previous = merged.get(canonical_path)

        try:
            count = int(entry.get("count", 0))
        except (TypeError, ValueError):
            count = 0

        timestamp = str(entry.get("last_downloaded", ""))

        if previous is None:
            merged[canonical_path] = {
                "path": saved_path,
                "count": count,
                "last_downloaded": timestamp,
            }
            continue

        # 같은 파일의 옛 경로와 새 경로가 같이 있으면
        # 더 큰 횟수와 더 최근 시각을 사용한다.
        previous["count"] = max(previous["count"], count)

        if timestamp > previous["last_downloaded"]:
            previous["last_downloaded"] = timestamp
            previous["path"] = saved_path

    records = list(merged.values())
    records.sort(
        key=lambda item: item["last_downloaded"],
        reverse=True,
    )

    if not records:
        list_html = """
        <div class="history-empty">
            아직 이 기기에서 받은 책이 없습니다.
        </div>
        """
    else:
        rows = []

        for record in records:
            saved_path = record["path"]
            filename = os.path.basename(saved_path)
            metadata = get_book_metadata(saved_path)

            title = metadata.get("title", "").strip()
            author = metadata.get("author", "").strip()

            if not title:
                title = os.path.splitext(filename)[0]

            timestamp = record["last_downloaded"]
            formatted_time = timestamp

            if timestamp:
                try:
                    formatted_time = datetime.fromisoformat(
                        timestamp
                    ).strftime("%Y-%m-%d %H:%M")
                except ValueError:
                    pass

            author_html = ""

            if author:
                author_html = f"""
                <div class="history-author">
                    {html.escape(author)}
                </div>
                """

            rows.append(
                f"""
                <article class="history-item">
                    <div class="history-title">
                        {html.escape(title)}
                    </div>

                    {author_html}

                    <div class="history-meta">
                        {record["count"]}회
                        · 마지막 {html.escape(formatted_time)}
                    </div>
                </article>
                """
            )

        list_html = "".join(rows)

    return f"""
    <div class="history-panel">
        <div class="history-panel-title">
            이 기기에 받은 책
        </div>

        <div class="history-list">
            {list_html}
        </div>
    </div>
    """


def format_download_history(entry):
    if not entry or entry.get("count", 0) < 1:
        return ""

    count = entry["count"]
    timestamp = entry.get("last_downloaded", "")
    formatted_time = ""

    if timestamp:
        try:
            formatted_time = datetime.fromisoformat(
                timestamp
            ).strftime("%m-%d %H:%M")
        except ValueError:
            formatted_time = timestamp

    if formatted_time:
        return f"{count}회 · 마지막 {formatted_time}"

    return f"{count}회"



def save_metadata_cache():
    METADATA_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    temporary_file = METADATA_CACHE_FILE.with_suffix(".json.tmp")

    with temporary_file.open("w", encoding="utf-8") as file:
        json.dump(
            METADATA_CACHE,
            file,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )

    temporary_file.replace(METADATA_CACHE_FILE)


def xml_local_name(tag):
    return tag.rsplit("}", 1)[-1].lower()


def clean_metadata_text(value):
    if not value:
        return ""

    return " ".join(str(value).split()).strip()


def read_epub_metadata(file_path):
    title = ""
    authors = []

    try:
        with zipfile.ZipFile(file_path, "r") as epub:
            container_data = epub.read("META-INF/container.xml")
            container_root = ET.fromstring(container_data)

            package_path = ""

            for element in container_root.iter():
                if xml_local_name(element.tag) != "rootfile":
                    continue

                package_path = element.attrib.get("full-path", "").strip()

                if package_path:
                    break

            if not package_path:
                raise ValueError("EPUB package 경로 없음")

            package_data = epub.read(package_path)
            package_root = ET.fromstring(package_data)

            for element in package_root.iter():
                local_name = xml_local_name(element.tag)
                value = clean_metadata_text(element.text)

                if not value:
                    continue

                if local_name == "title" and not title:
                    title = value
                elif local_name == "creator" and value not in authors:
                    authors.append(value)

    except (
        OSError,
        KeyError,
        ValueError,
        zipfile.BadZipFile,
        ET.ParseError,
    ):
        return {
            "title": "",
            "author": "",
        }

    return {
        "title": title,
        "author": ", ".join(authors),
    }


def get_book_metadata(file_path):
    file_path = os.path.abspath(file_path)
    extension = os.path.splitext(file_path)[1].lower()

    if extension != ".epub":
        return {
            "title": "",
            "author": "",
        }

    try:
        stat = os.stat(file_path)
    except OSError:
        return {
            "title": "",
            "author": "",
        }

    signature = {
        "mtime_ns": stat.st_mtime_ns,
        "size": stat.st_size,
    }

    with METADATA_CACHE_LOCK:
        cached = METADATA_CACHE.get(file_path)

        if (
            isinstance(cached, dict)
            and cached.get("mtime_ns") == signature["mtime_ns"]
            and cached.get("size") == signature["size"]
        ):
            return {
                "title": cached.get("title", ""),
                "author": cached.get("author", ""),
            }

    metadata = read_epub_metadata(file_path)

    cache_entry = {
        **signature,
        "title": metadata["title"],
        "author": metadata["author"],
    }

    with METADATA_CACHE_LOCK:
        METADATA_CACHE[file_path] = cache_entry

        try:
            save_metadata_cache()
        except OSError as error:
            print(f"[WARN] 메타데이터 캐시 저장 실패: {error}")

    return metadata


BOOK_TYPES = {
    ".epub": ("EPUB", "application/epub+zip"),
    ".pdf": ("PDF", "application/pdf"),
    ".mobi": ("MOBI", "application/x-mobipocket-ebook"),
    ".azw": ("AZW", "application/vnd.amazon.ebook"),
    ".azw3": ("AZW3", "application/vnd.amazon.ebook"),
    ".cbz": ("CBZ", "application/vnd.comicbook+zip"),
    ".cbr": ("CBR", "application/vnd.comicbook-rar"),
    ".txt": ("TXT", "text/plain; charset=utf-8"),
    ".ttf": ("TTF", "font/ttf"),
    ".otf": ("OTF", "font/otf"),
    ".woff": ("WOFF", "font/woff"),
    ".woff2": ("WOFF2", "font/woff2"),
}

TOKEN_PATTERN = re.compile(r"^[A-Za-z0-9_-]{4,80}$")
PROGRESS_TTL = 60 * 60


def human_size(size):
    units = ("B", "KB", "MB", "GB", "TB")
    value = float(size)

    for unit in units:
        if value < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(value)} {unit}"
            return f"{value:.1f} {unit}"
        value /= 1024

    return f"{size} B"


def safe_ascii_filename(filename):
    fallback_extension = os.path.splitext(filename)[1] or ".bin"

    ascii_name = (
        filename.encode("ascii", "ignore")
        .decode("ascii")
        .strip()
        .replace('"', "_")
        .replace("\\", "_")
    )

    if not ascii_name:
        ascii_name = f"book{fallback_extension}"

    return ascii_name


class ProgressStore:
    def __init__(self):
        self._items = {}
        self._lock = threading.Lock()

    def cleanup(self):
        cutoff = time.time() - PROGRESS_TTL

        with self._lock:
            expired = [
                token
                for token, item in self._items.items()
                if item.get("updated_at", 0) < cutoff
            ]

            for token in expired:
                self._items.pop(token, None)

    def start(self, token, filename, total, start_offset=0):
        now = time.time()

        with self._lock:
            previous = self._items.get(token, {})
            previous_sent = int(previous.get("sent", 0))

            self._items[token] = {
                "filename": filename,
                "total": total,
                "sent": max(previous_sent, start_offset),
                "status": "downloading",
                "message": "전송 중",
                "started_at": previous.get("started_at", now),
                "updated_at": now,
            }

    def update(self, token, absolute_sent):
        with self._lock:
            item = self._items.get(token)

            if not item:
                return

            item["sent"] = max(int(item.get("sent", 0)), int(absolute_sent))
            item["status"] = "downloading"
            item["message"] = "전송 중"
            item["updated_at"] = time.time()

    def complete(self, token):
        with self._lock:
            item = self._items.get(token)

            if not item:
                return

            item["sent"] = int(item.get("total", item.get("sent", 0)))
            item["status"] = "complete"
            item["message"] = "서버 전송 완료"
            item["updated_at"] = time.time()

    def interrupt(self, token):
        with self._lock:
            item = self._items.get(token)

            if not item:
                return

            item["status"] = "interrupted"
            item["message"] = "연결이 끊겼습니다"
            item["updated_at"] = time.time()

    def cancel(self, token):
        with self._lock:
            item = self._items.get(token)

            if not item:
                return

            item["status"] = "cancelled"
            item["message"] = "사용자가 전송을 취소했습니다"
            item["updated_at"] = time.time()

    def is_cancelled(self, token):
        with self._lock:
            item = self._items.get(token)
            return bool(item and item.get("status") == "cancelled")

    def error(self, token, message):
        with self._lock:
            item = self._items.setdefault(
                token,
                {
                    "filename": "",
                    "total": 0,
                    "sent": 0,
                    "started_at": time.time(),
                },
            )

            item["status"] = "error"
            item["message"] = message
            item["updated_at"] = time.time()

    def get(self, token):
        self.cleanup()

        with self._lock:
            item = self._items.get(token)

            if not item:
                return {
                    "status": "waiting",
                    "message": "다운로드 시작 대기 중",
                    "sent": 0,
                    "total": 0,
                    "percent": 0,
                }

            result = dict(item)

        total = int(result.get("total", 0))
        sent = int(result.get("sent", 0))

        if total > 0:
            percent = min(100, int(sent * 100 / total))
        else:
            percent = 0

        result["percent"] = percent
        result["sent_text"] = human_size(sent)
        result["total_text"] = human_size(total)

        return result


PROGRESS = ProgressStore()



ALLOWED_CLIENTS = {
    "127.0.0.1",
    "192.168.219.122",  # 카르타
    "192.168.219.131",    # 고7
    "192.168.219.240",    # 고7
    "192.168.219.126",  # S25
}

class BookHandler(SimpleHTTPRequestHandler):

    def is_client_allowed(self):
        return self.client_address[0] in ALLOWED_CLIENTS

    def reject_unallowed_client(self):
        client_ip = self.client_address[0]

        if self.is_client_allowed():
            return False

        print(f"[BLOCK] 허용되지 않은 접속: {client_ip}")

        body = "접근이 허용되지 않은 기기입니다.\n".encode("utf-8")

        self.send_response(403)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()

        if self.command != "HEAD":
            self.wfile.write(body)

        return True

    server_version = "PocketLibrary/2.0"
    protocol_version = "HTTP/1.1"

    extensions_map = {
        **SimpleHTTPRequestHandler.extensions_map,
        **{
            extension: mime
            for extension, (_, mime) in BOOK_TYPES.items()
        },
    }

    def do_GET(self):
        if self.reject_unallowed_client():
            return

        parsed = urlsplit(self.path)
        request_path = unquote(parsed.path)

        if request_path == "/favicon.ico":
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return

        if request_path == "/progress":
            self.serve_progress(parsed.query)
            return

        if request_path == "/cancel":
            self.serve_cancel(parsed.query)
            return

        if request_path.startswith("/download/"):
            self.serve_download(request_path, parsed.query, head_only=False)
            return

        local_path = self.translate_path(parsed.path)

        if os.path.isdir(local_path):
            response = self.list_directory(local_path)

            if response:
                try:
                    self.copyfile(response, self.wfile)
                finally:
                    response.close()
            return

        self.send_error(404, "파일을 찾을 수 없습니다.")

    def do_HEAD(self):
        if self.reject_unallowed_client():
            return

        parsed = urlsplit(self.path)
        request_path = unquote(parsed.path)

        if request_path.startswith("/download/"):
            self.serve_download(request_path, parsed.query, head_only=True)
            return

        local_path = self.translate_path(parsed.path)

        if os.path.isfile(local_path):
            self.send_file_headers(local_path, head_only=True)
            return

        self.send_error(404, "파일을 찾을 수 없습니다.")

    def serve_progress(self, query):
        params = parse_qs(query)
        token = params.get("id", [""])[0]

        if not TOKEN_PATTERN.fullmatch(token):
            self.send_json(
                {
                    "status": "error",
                    "message": "잘못된 다운로드 ID",
                    "sent": 0,
                    "total": 0,
                    "percent": 0,
                },
                status=400,
            )
            return

        self.send_json(PROGRESS.get(token))

    def serve_cancel(self, query):
        params = parse_qs(query)
        token = params.get("id", [""])[0]

        if not TOKEN_PATTERN.fullmatch(token):
            self.send_json(
                {
                    "status": "error",
                    "message": "잘못된 다운로드 ID",
                },
                status=400,
            )
            return

        PROGRESS.cancel(token)

        self.send_json(
            {
                "status": "cancelled",
                "message": "전송 취소 요청을 처리했습니다",
            }
        )

    def send_json(self, payload, status=200):
        encoded = json.dumps(
            payload,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")

        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()

        if self.command != "HEAD":
            self.wfile.write(encoded)

    def resolve_download_path(self, request_path):
        relative_url = request_path[len("/download/"):]
        relative_path = unquote(relative_url).replace("\\", "/")

        normalized = posixpath.normpath("/" + relative_path).lstrip("/")
        candidate = os.path.abspath(
            os.path.join(self.directory, *normalized.split("/"))
        )
        root = os.path.abspath(self.directory)

        try:
            common = os.path.commonpath((root, candidate))
        except ValueError:
            return None

        if common != root:
            return None

        if not os.path.isfile(candidate):
            return None

        return candidate

    def parse_range(self, range_header, file_size):
        if not range_header:
            return 0, file_size - 1, False

        match = re.fullmatch(r"bytes=(\d*)-(\d*)", range_header.strip())

        if not match:
            return None

        start_text, end_text = match.groups()

        try:
            if start_text:
                start = int(start_text)
                end = int(end_text) if end_text else file_size - 1
            else:
                suffix_length = int(end_text)

                if suffix_length <= 0:
                    return None

                start = max(0, file_size - suffix_length)
                end = file_size - 1
        except ValueError:
            return None

        if start < 0 or end < start or start >= file_size:
            return None

        end = min(end, file_size - 1)

        return start, end, True

    def serve_download(self, request_path, query, head_only=False):
        params = parse_qs(query)
        token = params.get("id", [""])[0]

        if not TOKEN_PATTERN.fullmatch(token):
            self.send_error(400, "잘못된 다운로드 ID")
            return

        local_path = self.resolve_download_path(request_path)

        if not local_path:
            PROGRESS.error(token, "파일을 찾을 수 없습니다")
            self.send_error(404, "파일을 찾을 수 없습니다.")
            return

        filename = os.path.basename(local_path)
        file_size = os.path.getsize(local_path)

        range_result = self.parse_range(
            self.headers.get("Range"),
            file_size,
        )

        if range_result is None:
            self.send_response(416)
            self.send_header("Content-Range", f"bytes */{file_size}")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return

        start, end, is_partial = range_result
        content_length = end - start + 1

        extension = os.path.splitext(filename)[1].lower()
        content_type = BOOK_TYPES.get(
            extension,
            ("FILE", mimetypes.guess_type(filename)[0] or "application/octet-stream"),
        )[1]

        PROGRESS.start(
            token,
            filename,
            file_size,
            start_offset=start,
        )

        self.send_response(206 if is_partial else 200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(content_length))
        self.send_header("Accept-Ranges", "bytes")

        if is_partial:
            self.send_header(
                "Content-Range",
                f"bytes {start}-{end}/{file_size}",
            )

        # 구형 Moon+가 다운로드 URL의 원래 파일명을 사용하도록
        # Content-Disposition 헤더는 보내지 않는다.
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()

        if head_only:
            return

        sent_this_request = 0
        chunk_size = 128 * 1024

        try:
            with open(local_path, "rb") as source:
                source.seek(start)
                remaining = content_length

                while remaining > 0:
                    if PROGRESS.is_cancelled(token):
                        print(
                            f"[BOOK] {self.client_address[0]} "
                            f"사용자 취소: {filename} "
                            f"({human_size(start + sent_this_request)} / "
                            f"{human_size(file_size)})"
                        )
                        return

                    chunk = source.read(min(chunk_size, remaining))

                    if not chunk:
                        break

                    self.wfile.write(chunk)
                    sent_this_request += len(chunk)
                    remaining -= len(chunk)

                    PROGRESS.update(
                        token,
                        start + sent_this_request,
                    )

            if sent_this_request == content_length:
                if end >= file_size - 1:
                    PROGRESS.complete(token)

                    record_download(
                        self.client_address[0],
                        local_path,
                        token,
                    )
                else:
                    PROGRESS.update(token, end + 1)

                print(
                    f"[BOOK] {self.client_address[0]} "
                    f"전송 완료: {filename} "
                    f"({human_size(sent_this_request)})"
                )
            else:
                PROGRESS.interrupt(token)

        except (BrokenPipeError, ConnectionResetError):
            PROGRESS.interrupt(token)

            print(
                f"[BOOK] {self.client_address[0]} "
                f"전송 중 연결 종료: {filename} "
                f"({human_size(start + sent_this_request)} / "
                f"{human_size(file_size)})"
            )

        except OSError as error:
            PROGRESS.error(token, f"전송 오류: {error}")

            print(
                f"[BOOK] 전송 오류: {filename}: {error}"
            )

    def send_file_headers(self, local_path, head_only=False):
        filename = os.path.basename(local_path)
        file_size = os.path.getsize(local_path)
        extension = os.path.splitext(filename)[1].lower()

        content_type = BOOK_TYPES.get(
            extension,
            ("FILE", mimetypes.guess_type(filename)[0] or "application/octet-stream"),
        )[1]

        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(file_size))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Connection", "close")
        self.end_headers()

    def list_directory(self, path):
        try:
            entries = sorted(
                os.listdir(path),
                key=lambda name: (
                    not os.path.isdir(os.path.join(path, name)),
                    name.casefold(),
                ),
            )
        except OSError:
            self.send_error(404, "폴더를 읽을 수 없습니다.")
            return None

        parsed = urlsplit(self.path)
        request_path = unquote(parsed.path)
        params = parse_qs(parsed.query)

        if not request_path.endswith("/"):
            request_path += "/"

        # 보기 옵션이 없는 주소는 스크롤 모드 URL로 이동
        if "view" not in params:
            redirect_path = quote(request_path, safe="/")

            self.send_response(302)
            self.send_header(
                "Location",
                redirect_path + "?view=page&page=1",
            )
            self.send_header("Content-Length", "0")
            self.send_header("Connection", "close")
            self.end_headers()
            return None

        view_mode = params.get("view", ["scroll"])[0]

        if view_mode not in ("scroll", "page"):
            view_mode = "scroll"

        try:
            current_page = max(
                1,
                int(params.get("page", ["1"])[0]),
            )
        except (TypeError, ValueError):
            current_page = 1

        items_per_page = 5
        display_entries = []

        for entry_name in entries:
            if entry_name.startswith("."):
                continue

            if entry_name.casefold() == "moonreader":
                continue

            entry_path = os.path.join(path, entry_name)

            if os.path.isdir(entry_path):
                display_entries.append(entry_name)
                continue

            extension = os.path.splitext(
                entry_name
            )[1].lower()

            if extension in BOOK_TYPES:
                display_entries.append(entry_name)

        search_query = params.get("q", [""])[0].strip()
        search_key = search_query.casefold()
        metadata_by_name = {}

        for entry_name in display_entries:
            entry_path = os.path.join(path, entry_name)

            if os.path.isfile(entry_path):
                metadata_by_name[entry_name] = get_book_metadata(entry_path)
            else:
                metadata_by_name[entry_name] = {
                    "title": "",
                    "author": "",
                }

        if search_key:
            filtered_entries = []

            for entry_name in display_entries:
                metadata = metadata_by_name.get(entry_name, {})
                searchable_text = " ".join(
                    (
                        entry_name,
                        metadata.get("title", ""),
                        metadata.get("author", ""),
                    )
                ).casefold()

                if search_key in searchable_text:
                    filtered_entries.append(entry_name)

            display_entries = filtered_entries

        total_items = len(display_entries)

        search_suffix = (
            "&q=" + quote(search_query)
            if search_query
            else ""
        )

        total_pages = max(
            1,
            (total_items + items_per_page - 1)
            // items_per_page,
        )

        current_page = min(current_page, total_pages)

        if view_mode == "page":
            page_start = (
                current_page - 1
            ) * items_per_page
            page_end = page_start + items_per_page
            entries = display_entries[page_start:page_end]
        else:
            entries = display_entries

        cards = []
        visible_count = 0

        if request_path != "/":
            parent_path = posixpath.dirname(
                request_path.rstrip("/")
            ) + "/"

            parent_url = (
                quote(parent_path, safe="/")
                + f"?view={view_mode}"
            )

            cards.append(
                f"""
                <a class="book-card folder-card"
                   href="{html.escape(parent_url)}">
                    <div class="type-icon">↩</div>
                    <div class="book-info">
                        <div class="book-title">상위 폴더</div>
                        <div class="book-meta">뒤로 가기</div>
                    </div>
                    <div class="open-button">열기</div>
                </a>
                """
            )

        for name in entries:
            if name.startswith("."):
                continue

            # Moon+ Reader가 만든 내부 폴더는 서재 목록에서 숨김
            if name.casefold() == "moonreader":
                continue

            full_path = os.path.join(path, name)
            encoded_name = quote(name)

            if os.path.isdir(full_path):
                folder_url = (
                    encoded_name
                    + "/"
                    + f"?view={view_mode}"
                )

                cards.append(
                    f"""
                    <a class="book-card folder-card searchable"
                       href="{html.escape(folder_url)}"
                       data-name="{html.escape(name.casefold())}">
                        <div class="type-icon">DIR</div>
                        <div class="book-info">
                            <div class="book-title">
                                {html.escape(name)}
                            </div>
                            <div class="book-meta">폴더</div>
                        </div>
                        <div class="open-button">열기</div>
                    </a>
                    """
                )

                visible_count += 1
                continue

            extension = os.path.splitext(name)[1].lower()

            if extension not in BOOK_TYPES:
                continue

            label, _ = BOOK_TYPES[extension]
            size = os.path.getsize(full_path)
            modified = datetime.fromtimestamp(
                os.path.getmtime(full_path)
            ).strftime("%Y-%m-%d %H:%M")

            relative_path = posixpath.join(
                request_path.lstrip("/"),
                name,
            )

            download_path = "/download/" + quote(
                relative_path,
                safe="/",
            )

            card_id = f"book-{visible_count}"
            entry_path = os.path.join(path, name)

            download_history = get_download_history(
                self.client_address[0],
                entry_path,
            )
            download_history_text = format_download_history(
                download_history
            )

            if download_history_text:
                downloaded_class = " downloaded"
                downloaded_badge_html = """
                <div class="downloaded-badge">
                    ✓ 받음
                </div>
                """
                download_history_html = f"""
                <div class="download-history">
                    {html.escape(download_history_text)}
                </div>
                """
            else:
                downloaded_class = ""
                downloaded_badge_html = ""
                download_history_html = ""

            cards.append(
                f"""
                <article class="book-card searchable{downloaded_class}"
                         data-name="{html.escape(name.casefold())}">
                    {downloaded_badge_html}
                    <div class="type-icon">{html.escape(label)}</div>

                    <div class="book-info">
                        <div class="book-title">
                            {html.escape(name)}
                        </div>

                        <div class="book-meta">
                            {html.escape(human_size(size))}
                            · {html.escape(modified)}
                        </div>

                        <div id="{card_id}-progress"
                             class="progress-area hidden">
                            <div class="progress-track">
                                <div id="{card_id}-bar"
                                     class="progress-bar"></div>
                            </div>

                            <div class="progress-row">
                                <span id="{card_id}-text">
                                    다운로드 준비 중
                                </span>
                                <strong id="{card_id}-percent">0%</strong>
                            </div>
                        </div>
                    </div>

                    <div class="card-actions">
                        <button id="{card_id}-download"
                                class="download-button"
                                type="button"
                                onclick="startDownload(
                                    '{card_id}',
                                    '{html.escape(download_path, quote=True)}',
                                    '{html.escape(name, quote=True)}'
                                )">
                            받기
                        </button>

                        {download_history_html}

                        <button id="{card_id}-cancel"
                                class="cancel-button hidden"
                                type="button"
                                onclick="cancelDownload('{card_id}')">
                            취소
                        </button>
                    </div>
                </article>
                """
            )

            visible_count += 1

        card_html = "".join(cards)

        encoded_base_path = quote(
            request_path,
            safe="/",
        )

        if view_mode == "scroll":
            switch_url = (
                encoded_base_path
                + "?view=page&page=1"
            )
            switch_label = "페이지 보기"
        else:
            switch_url = (
                encoded_base_path
                + "?view=scroll"
            )
            switch_label = "스크롤 보기"

        view_controls = f"""
        <div class="view-controls">
            <a class="view-button"
               href="{switch_url}">
                {switch_label}
            </a>
        </div>
        """

        pagination_html = ""

        if view_mode == "page":
            previous_page = max(
                1,
                current_page - 1,
            )
            next_page = min(
                total_pages,
                current_page + 1,
            )

            if current_page > 1:
                previous_html = f"""
                <a class="pager-button"
                   href="{encoded_base_path}?view=page&page={previous_page}{search_suffix}">
                    이전
                </a>
                """
            else:
                previous_html = """
                <span class="pager-button disabled">
                    이전
                </span>
                """

            if current_page < total_pages:
                next_html = f"""
                <a class="pager-button"
                   href="{encoded_base_path}?view=page&page={next_page}{search_suffix}">
                    다음
                </a>
                """
            else:
                next_html = """
                <span class="pager-button disabled">
                    다음
                </span>
                """

            first_html = f"""
            <a class="pager-button"
               href="{encoded_base_path}?view=page&page=1{search_suffix}">
                처음
            </a>
            """

            pagination_html = f"""
            <nav class="pagination">
                <div class="pager-row">
                    {previous_html}

                    <span class="page-status">
                        {current_page} / {total_pages}
                    </span>

                    {next_html}
                </div>

                <form class="page-jump"
                      method="get"
                      action="{encoded_base_path}">
                    <input type="hidden"
                           name="view"
                           value="page">

                    <input type="hidden"
                           name="q"
                           value="{html.escape(search_query)}">

                    {first_html}

                    <input class="page-input"
                           type="number"
                           name="page"
                           min="1"
                           max="{total_pages}"
                           value="{current_page}"
                           inputmode="numeric"
                           aria-label="이동할 페이지">

                    <button class="pager-button"
                            type="submit">
                        이동
                    </button>
                </form>
            </nav>
            """

        if not card_html:
            card_html = (
                '<div class="empty">이 폴더에 표시할 책이 없습니다.</div>'
            )

        body = f"""<!doctype html>
<html lang="ko">
<head>
    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1, viewport-fit=cover"
    >

    <title>내 서재</title>

    <style>
        * {{
            box-sizing: border-box;
        }}

        html {{
            background: #ece9e1;
        }}

        body {{
            margin: 0;
            color: #25231f;
            background: #ece9e1;
            font-family:
                -apple-system,
                BlinkMacSystemFont,
                "Noto Sans KR",
                Arial,
                sans-serif;
        }}

        button,
        input {{
            font: inherit;
        }}

        .page {{
            width: 100%;
            max-width: 820px;
            margin: 0 auto;
            padding: 16px 12px 42px;
        }}

        .hero {{
            margin-bottom: 14px;
            padding: 20px;
            background: #fffef9;
            border: 1px solid #cfc9bb;
            border-radius: 16px;
        }}

        .hero h1 {{
            margin: 0 0 7px;
            font-size: 25px;
            line-height: 1.25;
        }}

        .hero-description {{
            color: #666056;
            font-size: 14px;
            line-height: 1.6;
        }}

        .notice {{
            margin-top: 13px;
            padding: 11px 12px;
            color: #474238;
            background: #f1eee5;
            border: 1px solid #ddd7ca;
            border-radius: 10px;
            font-size: 13px;
            line-height: 1.55;
        }}

        .search-form {{
            display: flex;
            gap: 8px;
            margin: 0 0 13px;
        }}

        .search-box {{
            flex: 1;
            min-width: 0;
            width: 100%;
            margin: 0;
            padding: 13px 14px;
            color: #222;
            background: #fffef9;
            border: 1px solid #c8c1b4;
            border-radius: 12px;
            outline: none;
            font-size: 16px;
        }}

        .search-box:focus {{
            border-color: #777064;
        }}

        .search-button {{
            flex: 0 0 auto;
            padding: 0 16px;
            color: #28251f;
            background: #ebe6db;
            border: 1px solid #bdb5a7;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 700;
        }}

        .view-controls {{
            margin: 0 0 13px;
        }}

        .view-button {{
            display: block;
            width: 100%;
            padding: 11px 12px;
            color: #37332d;
            background: #fffef9;
            border: 1px solid #aaa295;
            border-radius: 10px;
            text-align: center;
            text-decoration: none;
            font-size: 14px;
            font-weight: 700;
        }}

        .view-button:active {{
            background: #e2ddd2;
        }}

        .pagination {{
            display: flex;
            flex-direction: column;
            gap: 9px;
            margin: 13px 0;
            padding: 10px;
            background: #fffef9;
            border: 1px solid #d1cabc;
            border-radius: 11px;
        }}

        .pager-row {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 7px;
        }}

        .page-jump {{
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
        }}

        .page-input {{
            width: 72px;
            padding: 9px 8px;
            color: #28251f;
            background: #fffef9;
            border: 1px solid #bdb5a7;
            border-radius: 9px;
            text-align: center;
            font-size: 15px;
        }}

        .pager-button {{
            min-width: 68px;
            padding: 9px 10px;
            color: #292620;
            background: #f1eee6;
            border: 1px solid #999184;
            border-radius: 8px;
            text-align: center;
            text-decoration: none;
        }}

        .pager-button.disabled {{
            color: #aaa398;
            background: #eeeae2;
            border-color: #d3cdc1;
        }}

        .page-status {{
            color: #555047;
            font-size: 14px;
            font-weight: 700;
            white-space: nowrap;
        }}

        .book-card {{
            display: flex;
            align-items: center;
            gap: 12px;
            min-height: 82px;
            margin-bottom: 10px;
            padding: 13px;
            color: inherit;
            background: #fffef9;
            border: 1px solid #d1cabc;
            border-radius: 14px;
            text-decoration: none;
        }}

        .folder-card:active {{
            background: #e4dfd4;
        }}

        .type-icon {{
            display: flex;
            align-items: center;
            justify-content: center;
            width: 57px;
            min-width: 57px;
            height: 44px;
            padding: 4px;
            color: #37332c;
            border: 1px solid #918a7e;
            border-radius: 9px;
            font-size: 12px;
            font-weight: 800;
        }}

        .book-info {{
            flex: 1;
            min-width: 0;
        }}

        .book-title {{
            overflow-wrap: anywhere;
            font-size: 16px;
            font-weight: 750;
            line-height: 1.42;
        }}

        .book-meta {{
            margin-top: 5px;
            color: #777065;
            font-size: 12px;
        }}

        .card-actions {{
            display: flex;
            flex-direction: column;
            gap: 6px;
        }}

        .download-button,
        .cancel-button,
        .open-button {{
            min-width: 54px;
            padding: 9px 10px;
            color: #24211d;
            background: #f1eee6;
            border: 1px solid #999184;
            border-radius: 9px;
            text-align: center;
            white-space: nowrap;
        }}

        .download-button:active,
        .cancel-button:active {{
            background: #dcd6ca;
        }}

        .cancel-button {{
            min-width: 54px;
            padding: 8px 10px;
            color: #4d2828;
            background: #f3e9e7;
            border: 1px solid #a68b86;
            border-radius: 9px;
            text-align: center;
            white-space: nowrap;
        }}

        .progress-area {{
            margin-top: 11px;
        }}

        .progress-track {{
            width: 100%;
            height: 11px;
            overflow: hidden;
            background: #ddd8ce;
            border: 1px solid #c1baad;
            border-radius: 999px;
        }}

        .progress-bar {{
            width: 0%;
            height: 100%;
            background: #4f6d58;
            transition: width 0.25s linear;
        }}

        .progress-row {{
            display: flex;
            justify-content: space-between;
            gap: 8px;
            margin-top: 5px;
            color: #686157;
            font-size: 12px;
            line-height: 1.4;
        }}

        .progress-row strong {{
            color: #38342e;
            white-space: nowrap;
        }}

        .hidden {{
            display: none;
        }}

        .empty {{
            padding: 34px 16px;
            color: #777065;
            background: #fffef9;
            border: 1px solid #d1cabc;
            border-radius: 14px;
            text-align: center;
        }}

        .footer {{
            margin-top: 18px;
            color: #777065;
            text-align: center;
            font-size: 12px;
            line-height: 1.6;
        }}

        #downloadFrame {{
            display: none;
            width: 0;
            height: 0;
            border: 0;
        }}

        @media (max-width: 480px) {{
            .page {{
                padding: 9px 7px 30px;
            }}

            .hero {{
                padding: 15px;
                border-radius: 10px;
            }}

            .book-card {{
                gap: 9px;
                padding: 11px 9px;
                border-radius: 9px;
            }}

            .type-icon {{
                width: 48px;
                min-width: 48px;
            }}

            .download-button,
            .open-button {{
                min-width: 47px;
                padding: 8px 7px;
            }}
        }}

        .download-history {{
            margin-top: 6px;
            color: #716a5f;
            font-size: 11px;
            line-height: 1.35;
            text-align: center;
            white-space: nowrap;
        }}


        .book-card.downloaded {{
            position: relative;
            background: #eef3e9;
            border-color: #9eae91;
        }}

        .book-card.downloaded .type-icon {{
            background: #dfe8d7;
            border-color: #a9b99d;
        }}

        .downloaded-badge {{
            position: absolute;
            top: 7px;
            right: 8px;
            padding: 3px 7px;
            color: #495943;
            background: #dce7d4;
            border: 1px solid #a7b89a;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 700;
            line-height: 1.2;
        }}


        .library-title {{
            display: inline-block;
            margin: 0;
            padding: 0;
            color: inherit;
            background: transparent;
            border: 0;
            text-decoration: none;
            font: inherit;
            font-size: 30px;
            font-weight: 800;
            line-height: 1.2;
            cursor: pointer;
        }}

        .library-title::after {{
            content: "  ▾";
            color: #777064;
            font-size: 15px;
            vertical-align: middle;
        }}

        .history-modal {{
            position: fixed;
            z-index: 9999;
            inset: 0;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 18px;
            background: rgba(30, 28, 24, 0.58);
        }}

        .history-modal:target {{
            display: flex;
        }}

        .history-backdrop {{
            position: absolute;
            inset: 0;
        }}

        .history-dialog {{
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 520px;
            max-height: 82vh;
            overflow: hidden;
            background: #fffdf7;
            border: 1px solid #aaa295;
            border-radius: 15px;
            box-shadow: 0 12px 35px rgba(0, 0, 0, 0.28);
        }}

        .history-header {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 15px 16px;
            border-bottom: 1px solid #d8d1c5;
        }}

        .history-header h2 {{
            margin: 0;
            color: #302c26;
            font-size: 19px;
        }}

        .history-close {{
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 38px;
            min-height: 38px;
            padding: 0;
            color: #49443d;
            background: #eee9df;
            border: 1px solid #c5bdaf;
            border-radius: 10px;
            font-size: 25px;
            line-height: 1;
            text-decoration: none;
        }}

        .history-list {{
            max-height: calc(82vh - 70px);
            overflow-y: auto;
            padding: 12px;
        }}

        .history-item {{
            margin-bottom: 9px;
            padding: 12px 13px;
            background: #f2f5ed;
            border: 1px solid #bdc9b3;
            border-radius: 11px;
        }}

        .history-item:last-child {{
            margin-bottom: 0;
        }}

        .history-title {{
            padding-right: 4px;
            color: #292620;
            font-size: 15px;
            font-weight: 700;
            line-height: 1.45;
        }}

        .history-author {{
            margin-top: 4px;
            color: #625d54;
            font-size: 13px;
            line-height: 1.4;
        }}

        .history-meta {{
            margin-top: 6px;
            color: #777064;
            font-size: 12px;
        }}

        .history-empty {{
            padding: 28px 15px;
            color: #777064;
            text-align: center;
            font-size: 14px;
        }}


        .library-history {{
            margin: 0;
        }}

        .library-title {{
            display: inline-block;
            margin: 0;
            padding: 0;
            color: inherit;
            background: transparent;
            border: 0;
            font: inherit;
            font-size: 30px;
            font-weight: 800;
            line-height: 1.2;
            cursor: pointer;
            list-style: none;
        }}

        .library-title::-webkit-details-marker {{
            display: none;
        }}

        .library-title::after {{
            content: "  ▾";
            color: #777064;
            font-size: 15px;
            vertical-align: middle;
        }}

        .library-history[open] .library-title::after {{
            content: "  ▴";
        }}

        .history-panel {{
            margin-top: 14px;
            overflow: hidden;
            background: #fffdf7;
            border: 1px solid #aaa295;
            border-radius: 13px;
            text-align: left;
        }}

        .history-panel-title {{
            padding: 12px 14px;
            color: #302c26;
            background: #eee9df;
            border-bottom: 1px solid #d8d1c5;
            font-size: 16px;
            font-weight: 700;
        }}

        .history-list {{
            max-height: 55vh;
            overflow-y: auto;
            padding: 10px;
        }}

    </style>
</head>

<body>
    <main class="page">
        <section class="hero">
            <details class="library-history">
                <summary class="library-title">
                    내 도서관
                </summary>

                {build_download_history_modal(self.client_address[0])}
            </details>

            <div class="hero-description">
                책을 누르면 폰 서버에서 리더기로 전송합니다.
            </div>

            <div class="notice">
                게이지 100%는 서버 전송 완료를 뜻합니다.<br>
                Moon+에서 <strong>.epub.mr</strong> 파일을
                <strong>.epub</strong>으로 정리하는 데 시간이 더 걸릴 수 있습니다.
            </div>
        </section>

        <form class="search-form"
              method="get"
              action="{encoded_base_path}">
            <input type="hidden"
                   name="view"
                   value="{view_mode}">

            <input
                id="search"
                class="search-box"
                type="search"
                name="q"
                value="{html.escape(search_query)}"
                placeholder="책 제목·저자 검색"
                autocomplete="off"
            >

            <button class="search-button"
                    type="submit">
                검색
            </button>
        </form>

        {view_controls}

        {pagination_html}

        <section id="bookList">
            {card_html}
        </section>

        {pagination_html}

        <div class="footer">
            표시된 항목: {visible_count}개
            / 전체 {total_items}개<br>
            Pocket Library · Termux
        </div>

        <iframe
            id="downloadFrame"
            name="downloadFrame"
            title="download"
        ></iframe>
    </main>

    <script>
        (function () {{
            var search = document.getElementById("search");
            var cards = document.querySelectorAll(".searchable");

            search.addEventListener("input", function () {{
                var query = search.value.toLowerCase();

                for (var i = 0; i < cards.length; i++) {{
                    var name = cards[i].getAttribute("data-name") || "";

                    cards[i].style.display =
                        name.indexOf(query) !== -1 ? "flex" : "none";
                }}
            }});
        }})();

        var activeDownloads = {{}};

        function makeToken() {{
            return (
                Date.now().toString(36)
                + "-"
                + Math.random().toString(36).slice(2, 12)
            );
        }}

        function startDownload(cardId, downloadPath, filename) {{
            var token = makeToken();
            var progressBox = document.getElementById(
                cardId + "-progress"
            );
            var bar = document.getElementById(cardId + "-bar");
            var text = document.getElementById(cardId + "-text");
            var percent = document.getElementById(
                cardId + "-percent"
            );
            var frame = document.getElementById("downloadFrame");
            var cancelButton = document.getElementById(
                cardId + "-cancel"
            );
            var downloadButton = document.getElementById(
                cardId + "-download"
            );

            activeDownloads[cardId] = token;

            if (downloadButton) {{
                downloadButton.textContent = "받는 중";
                downloadButton.disabled = true;
            }}
            cancelButton.className = "cancel-button";

            progressBox.className = "progress-area";
            bar.style.width = "0%";
            text.textContent = "다운로드 연결 중: " + filename;
            percent.textContent = "0%";

            frame.src =
                downloadPath
                + "?id="
                + encodeURIComponent(token)
                + "&t="
                + Date.now();

            pollProgress(
                cardId,
                token,
                bar,
                text,
                percent,
                0
            );
        }}

        function cancelDownload(cardId) {{
            var token = activeDownloads[cardId];

            if (!token) {{
                return;
            }}

            var frame = document.getElementById("downloadFrame");
            var bar = document.getElementById(cardId + "-bar");
            var text = document.getElementById(cardId + "-text");
            var percent = document.getElementById(
                cardId + "-percent"
            );
            var cancelButton = document.getElementById(
                cardId + "-cancel"
            );

            var request = new XMLHttpRequest();

            request.open(
                "GET",
                "/cancel?id="
                    + encodeURIComponent(token)
                    + "&t="
                    + Date.now(),
                true
            );

            request.send(null);

            frame.src = "about:blank";

            text.textContent = "사용자가 전송을 취소했습니다";
            percent.textContent = "취소";
            bar.style.width = "0%";
            cancelButton.className = "cancel-button hidden";

            var downloadButton = document.getElementById(
                cardId + "-download"
            );

            if (downloadButton) {{
                downloadButton.textContent = "받기";
                downloadButton.disabled = false;
            }}

            delete activeDownloads[cardId];
        }}

        function pollProgress(
            cardId,
            token,
            bar,
            text,
            percent,
            misses
        ) {{
            var request = new XMLHttpRequest();

            request.open(
                "GET",
                "/progress?id="
                    + encodeURIComponent(token)
                    + "&t="
                    + Date.now(),
                true
            );

            request.onreadystatechange = function () {{
                if (request.readyState !== 4) {{
                    return;
                }}

                if (request.status !== 200) {{
                    if (misses < 20) {{
                        setTimeout(function () {{
                            pollProgress(
                                cardId,
                                token,
                                bar,
                                text,
                                percent,
                                misses + 1
                            );
                        }}, 700);
                    }} else {{
                        text.textContent = "진행 상태를 확인할 수 없습니다";
                    }}

                    return;
                }}

                var data;

                try {{
                    data = JSON.parse(request.responseText);
                }} catch (error) {{
                    text.textContent = "진행 정보 해석 오류";
                    return;
                }}

                var value = data.percent || 0;

                bar.style.width = value + "%";
                percent.textContent = value + "%";

                if (data.total > 0) {{
                    text.textContent =
                        data.sent_text
                        + " / "
                        + data.total_text
                        + " · "
                        + data.message;
                }} else {{
                    text.textContent = data.message;
                }}

                if (data.status === "complete") {{
                    var progressBox = document.getElementById(
                        cardId + "-progress"
                    );
                    var downloadButton = document.getElementById(
                        cardId + "-download"
                    );

                    document.getElementById(
                        cardId + "-cancel"
                    ).className = "cancel-button hidden";

                    if (progressBox) {{
                        progressBox.className = "progress-area hidden";
                    }}

                    if (downloadButton) {{
                        downloadButton.textContent = "완료";
                        downloadButton.disabled = false;
                    }}

                    delete activeDownloads[cardId];
                    return;
                }}

                if (data.status === "cancelled") {{
                    bar.style.width = "0%";
                    percent.textContent = "취소";
                    text.textContent = data.message;

                    document.getElementById(
                        cardId + "-cancel"
                    ).className = "cancel-button hidden";

                    delete activeDownloads[cardId];
                    return;
                }}

                if (data.status === "error") {{
                    return;
                }}

                if (data.status === "interrupted") {{
                    text.textContent =
                        data.sent_text
                        + " / "
                        + data.total_text
                        + " · 연결 끊김 또는 재시도 중";
                }}

                setTimeout(function () {{
                    pollProgress(
                        cardId,
                        token,
                        bar,
                        text,
                        percent,
                        0
                    );
                }}, 500);
            }};

            request.send(null);
        }}
    </script>

    <script>
        function openHistoryModal() {{
            const modal = document.getElementById("historyModal");

            if (modal) {{
                modal.classList.remove("hidden");
                document.body.style.overflow = "hidden";
            }}
        }}

        function closeHistoryModal(event) {{
            if (
                event &&
                event.target &&
                event.target.id !== "historyModal"
            ) {{
                return;
            }}

            const modal = document.getElementById("historyModal");

            if (modal) {{
                modal.classList.add("hidden");
                document.body.style.overflow = "";
            }}
        }}

        document.addEventListener("keydown", function(event) {{
            if (event.key === "Escape") {{
                closeHistoryModal();
            }}
        }});
    </script>

</body>
</html>
"""

        encoded = body.encode("utf-8")

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()

        return BytesIO(encoded)

    def log_message(self, fmt, *args):
        print(
            f"[BOOK] {self.client_address[0]} - {fmt % args}"
        )


def main():
    parser = argparse.ArgumentParser(
        description="Termux 개인 전자책 서버"
    )

    parser.add_argument(
        "--directory",
        default=os.path.expanduser(
            "~/storage/shared/Mine/Books"
        ),
    )
    parser.add_argument("--port", type=int, default=8083)
    parser.add_argument("--bind", default="0.0.0.0")

    args = parser.parse_args()

    directory = os.path.abspath(
        os.path.expanduser(args.directory)
    )

    if not os.path.isdir(directory):
        raise SystemExit(
            f"[ERROR] Books 폴더가 없습니다: {directory}"
        )

    def handler_factory(*handler_args, **handler_kwargs):
        return BookHandler(
            *handler_args,
            directory=directory,
            **handler_kwargs,
        )

    server = ThreadingHTTPServer(
        (args.bind, args.port),
        handler_factory,
    )

    server.daemon_threads = True
    server.allow_reuse_address = True

    print(f"[BOOK] 폴더: {directory}")
    print(f"[BOOK] 포트: {args.port}")
    print("[BOOK] 주소: http://192.168.219.126:8083/")
    print("[BOOK] 종료: Ctrl+C")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[BOOK] 서버 종료")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
